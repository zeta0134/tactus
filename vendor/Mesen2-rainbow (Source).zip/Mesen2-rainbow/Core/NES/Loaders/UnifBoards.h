#pragma once
#include "pch.h"

namespace UnifBoards {
	enum UnifBoards
	{
		UnknownBoard = 32768,
		Malee,
		Gs2013,
		Ghostbusters63in1,
		Super24in1Sc03,
		Cc21,
		Ac08,
		UnlPuzzle,
		Fk23C,
		Fk23Ca,
		Unl255in1,
		UnlVrc7,
		Unl8237A,
		SssNrom256,
	};
}